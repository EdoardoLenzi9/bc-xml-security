namespace Org.BouncyCastle.X509
{
    public enum X509IncludeOption
    {
        None = 0,
        ExcludeRoot,
        EndCertOnly,
        WholeChain
    }
}
