using System;

namespace Org.BouncyCastle.Crypto.Xml
{
    internal enum ReferenceTargetType
    {
        Stream,
        XmlElement,
        UriReference
    }
}
