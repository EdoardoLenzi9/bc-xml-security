﻿using System;

namespace Org.BouncyCastle.Crypto.Xml
{
    internal enum DocPosition
    {
        BeforeRootElement,
        InRootElement,
        AfterRootElement
    }
}
