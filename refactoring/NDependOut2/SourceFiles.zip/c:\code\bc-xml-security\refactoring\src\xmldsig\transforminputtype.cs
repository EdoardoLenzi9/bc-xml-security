



using System;

namespace Org.BouncyCastle.Crypto.Xml
{
    internal enum TransformInputType
    {
        XmlDocument = 1,
        XmlStream = 2,
        XmlNodeSet = 3
    }
}
