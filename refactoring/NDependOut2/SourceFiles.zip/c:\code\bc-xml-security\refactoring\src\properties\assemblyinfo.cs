﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("XML Security using Bouncy Castle")]
[assembly: AssemblyDescription("Implementation of the XML Security standards using Bouncy Castle")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("bc-xml-security")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: Guid("a1ebcbae-8e6d-4af6-958b-86a5b2ec744c")]






[assembly: AssemblyVersion("1.0.1.0")]
[assembly: AssemblyFileVersion("1.0.1.0")]
